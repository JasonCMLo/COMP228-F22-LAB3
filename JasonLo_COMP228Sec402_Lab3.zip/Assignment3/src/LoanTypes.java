public enum LoanTypes {
    Computer,
    Accomodation,
    Tuition
}
